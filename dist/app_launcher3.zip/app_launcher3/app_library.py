apps = {
    ' Apex Legends':{'path':'steam://rungameid/1172470','icon':'launcher/apex.png'},
    ' Persona 4':{'path':'steam://rungameid/14752010393073221632','icon':'D:/game/Persona 4 Golden/P4G-2.ico'},
    ' Fate/Grand Order':{'path':'steam://rungameid/9552918216016134144','icon':'C:/ProgramData/BlueStacks_nxt/Engine/Pie64/AppCache/com.aniplex.fategrandorder.en.png'},
    ' Integral Factor':{'path':'steam://rungameid/2371630','icon':'D:/game/launcher/if.ico'},
}